import java.util.Dictionary;
import java.util.Enumeration;
import java.util.Hashtable;
public class Resultado
{
    public static void main(String[]args){
        Dictionary<String, Integer> dic = new Hashtable<String, Integer>();
        String[] palabras = {"as","toga","gato","gota","botas","gasto","gotas"};
        int[] puntos ={2,5,5,5,7,6,6};
        for (int i = 0; i < palabras.length; i++){
            dic.put(palabras[i],puntos[i]);
        }
 /**       dic.put("as","2");
        dic.put("toga","5");
        dic.put("gato","5");
        dic.put("gota","5");
        dic.put("botas","7");
        dic.put("gasto","6");
        dic.put("gotas","6");
  */      
        System.out.println("tamaño " + dic.size());
        System.out.println("Llave 3: " + dic.get("botas"));
        
}
}
