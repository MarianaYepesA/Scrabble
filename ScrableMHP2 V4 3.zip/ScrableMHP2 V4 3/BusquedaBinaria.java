public class BusquedaBinaria
{
    public static void main (String[]args){
        int [] arr_edades = {10,20,30,40,50};
        int buscar = 40;
        int resul = -1;
        int ini = 0;
        int fin = arr_edades.length - 1;
        int pos;
        while(ini<=fin){
            pos = (ini + fin)/2;
            if(buscar == arr_edades[pos]){
                resul = pos;
                break;
            }else if (buscar <= arr_edades[pos]){
                fin = pos -1;
            }else{
                ini = pos + 1;
            }
        }
            System.out.println("La pos de " + buscar +" es: "+ resul);

}
}
