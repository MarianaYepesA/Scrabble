/**
 *  Clase Tablero para el juego de Scrabble.
 *  
 *  Este método pide al jugador la palabra que desea colocar (de
 *  las mejores palabras entregadas por la Fase 1) y la fila y la columna
 *  en la cual quiere que inicie la palabra. Luego imprime 
 *  el tablero con la palabra ingresada mas todas las palabras anteriores.
 *  La clase tiene otros dos métodos: palabraEnTablero e imprimirTablero. Se
 *  explican mas abajo.
 *  
 *  Versión 05.05.2021
 *  Por Mariana Yepes y Hernán Moreno
 */

import java.util.ArrayList;
import java.util.Scanner;
public class Tablero
{
    public static String[][] tablero = new String[15][15];
    /**
     * Método borrarTablero: coloca " " en todas las posiciones de la matriz.
     */
    public static void borrarTablero(){
    for (int f = 0; f <= 14;f ++){
         for (int c = 0; c <= 14; c ++){
             tablero[f][c] = " ";
         }
    }
}
    /**
     * Método Tablero:
     * 
     * El jugador analiza el tablero, y decide cual de sus "mejores palabras"
     * desea colocar y le informa al programa esa palabra, su posición inicial, 
     * y el sentido (Horizontal o Vertical). El programa colocará entonces la 
     * palabra en la posición indicada e imprimirá nuevamente el tablero.
     * Si la palabra no cabe en la posición escogida, el programa informa de
     * ello al jugador el cual tiene otra opción.
     * 
     */
    public static void Tablero(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Ingrese la palabra a colocar: ");
        String palabranueva = scan.next();
        System.out.println("En cual fila la quiere colocar?");
        int fila = scan.nextInt();
        System.out.println("En cual columna?");
        int columna = scan.nextInt();
        System.out.println("Horizontal o Vertical? (H o V)");
        String sentido = scan.next();
        if(sentido .equals("H")){
            if(palabranueva.length()>15 - columna){
                System.out.println("La palabra no cabe, intene de nuevo"); 
            }else{
            
                for(int i = 0; i < palabranueva.length(); i++){

                tablero[fila][columna + i] = palabranueva.substring(i,i+1);
            }
            System.out.println("El puntaje para esta palabra es: "+ puntaje.puntaje(palabranueva));

        }
        }else{
            if(palabranueva.length()>15 - fila){
                System.out.println("La palabra no cabe, intente de nuevo");
            }else{

            for(int i = 0; i < palabranueva.length(); i++){
    
                tablero[fila + i][columna] = palabranueva.substring(i,i+1);
            }
            System.out.println("El puntaje para esta palabra es: "+ puntaje.puntaje(palabranueva));

        }
    }
        imprimirTablero();

}
    /**
     * Método palabraEnTablero.
     * 
     * NOTA: este método no se está usando. Es una prueba para que el programa
     * encuentre por si solo una palabra horizontal en el tablero.
     * 
     * Cuando es nuevamente el turno del jugador A,
     * busca una palabra en el tablero en sentido horizontal, imprime letra por
     * letra y luego el tablero con la palabra incluida. Esta versión inicial, 
     * solamente busca una palabra en sentido horizontal (la primera que encuen-
     * tre). Una versión posterior debe encontrar todas las palabras que haya
     * en el tablero tanto horizontales como verticales e imprmir el tablero
     * completo.
     */
    public static void palabraEnTablero(){
        String[] palent = new String[7];
        int i = 0;
        for (int f = 0; f < 10; f ++){
            for (int c = 0; c < 10; c ++){
                if(tablero[f][c].equals(" ")){
                    continue;
                }else{
                    palent[i] = tablero[f][c];
                    System.out.println("i: " + i +" " + palent[i]);
                    i = i+ 1;
                }
            }
            i = 0;
        }
        for (int k = 0; k <7; k ++){
            System.out.print(palent[k]);
        }
        System.out.println("tablero: " + tablero[7][7]);
    imprimirTablero();
    }
    /**
     * Método imprimirTablero: Simplemente imprime el tablero en su confi-
     * guración actual. Puede invocarse desde cualquier parte del paquete.
     */
    public static void imprimirTablero(){
        System.out.print("  ||0|1|2|3|4|5|6|7|8|9|0|1|2|3|4|");
        System.out.println(" ");
        System.out.println("----------------------------------");

        for(int f = 0; f < 15; f ++){
            if(f<=9){
            System.out.print(f + " |");
        }else{
            System.out.print(f + "|");
        }
            System.out.print("|");
            for (int c = 0; c < 15; c ++){
                System.out.print(Tablero.tablero[f][c]);
                System.out.print("|");
            }
            System.out.println(" ");
            System.out.println("----------------------------------");

        }
}
}
