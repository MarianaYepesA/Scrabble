import java.util.ArrayList;
public class Selectsort
{
    public static void main (String[]args){
        ArrayList <Integer> arr_edades = new ArrayList <Integer>();
        arr_edades.add(50);
        arr_edades.add(40);
        arr_edades.add(30);
        arr_edades.add(20);
        arr_edades.add(10);
//        int [] arr_edades = {50,40,30,10,20};
//        int n = arr_edades.length;
        int n = arr_edades.size();
        int pos_menor, temp;
        for (int i = 0; i < n-1; i++){
            pos_menor = i;
            for (int j = i+1; j < n; j ++){
                if(arr_edades.get(j) < arr_edades.get(pos_menor)){
                    pos_menor = j;
                }
            }
            temp = arr_edades.get(i);
            arr_edades.set(i, arr_edades.get(pos_menor));
            arr_edades.set(pos_menor, temp);
        }
        for (int i = 0; i<n; i++){
            System.out.println(arr_edades.get(i));
        }
}
}
