public class Tuspalabras
{
    public static void Tuspalabras(){
    int cant = LetterCombinations.palabrasbuenas.size();
    int mayor = cant;
    if(cant <= 10){
        return;
    }
    for(int i = mayor; i == 0; i=i-2){
        if(LetterCombinations.palabrasbuenas.get(i).compareTo(LetterCombinations
        .palabrasbuenas.get(i-2))<0){
            mayor = i - 2;
        }
    }
    System.out.println(LetterCombinations.palabrasbuenas.get(mayor));
}
}
