
/**
 * Clase principal para el juego de Scrabble. Trabajo Final Fundamentos, Parte 2.
 * Esta clase crea el diccionario (Clase Diccionario), (las palabras se leen de un archivo),y lo ordena
 * alfabéticamente.
 * luego crea el tablero (Clase Tablero) de 15 x 15, y usa la clase LetterCombinations
 * para crear las palabras posibles, de acuerdo a las letras que el jugador
 * tiene en su mano, y presenta a su consideración las 10 mejores según su
 * puntaje, calculado por la clase Puntaje.
 *  
 * 
 * @author Helmuth Trefftz, modificado por Mariana Yepes y Hernan Moreno
 * @version original 2021 04 27
 * @version modificada 2021 05 06
 */
import java.util.Scanner;
public class Scrabble
{
    /**
     * Programa principal
     * Se crea y se ordena alfabéticamente el diccionario
     * y luego se invoca el método
     * crearPalabras de la clase LetterCombinations
     * para que imprima palabras que se pueden crear a partir
     * de las letras que el usuario tiene en la mano y que se 
     * encuentren en el diccionario, con el puntaje correspondiente
     * calculado con el método puntaje.
     * El programa pide el nombre del diccionario que se va a utilizar.
     * y las letras que tiene a la mano
     */
    public static void main(String [] args) {
        Diccionario diccionario = new Diccionario();
        Tablero tablero = new Tablero();
        Scanner scan = new Scanner(System.in);
        System.out.println("Ingrese el nombre del diccionario .txt");
        String archivo = scan.next();
        diccionario.leerDiccionario(archivo);
        diccionario.ordenarDiccionario();
        tablero.borrarTablero();
        LetterCombinations lc = new LetterCombinations(diccionario);
        System.out.println("Ingrese las letras en su mano, o fin para terminar el juego:");
        String letrasEnMiMano = scan.next();
        while(letrasEnMiMano.equals ("fin") == false){
            lc.crearPalabras(letrasEnMiMano);
            diccionario.Tuspalabras();
            tablero.Tablero();
            System.out.println("Ingrese las letras en su mano, o fin para terminar el juego:");
            letrasEnMiMano = scan.next();

        }
        if(letrasEnMiMano.equals ("fin")){
            System.out.println("Gracias por jugar Scrabble MH");
        }

        }
        
    }


