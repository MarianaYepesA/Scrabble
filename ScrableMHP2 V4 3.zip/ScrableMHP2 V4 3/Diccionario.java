
/**
 * En esta clase se maneja el diccionario con palabras válidas para el
 * juego Scrabble.
 * Las palabras se leen de un archivo texto, en el cual cada palabra
 * está en una línea diferente
 * Tiene 4 métodos, asi:
 *  - leerDiccionario: lee el diccionario de un archivo .txt
 *  - ordenarDiccionario: Ordena el diccionario usando el método binario
 *  - buscarPalabras: busca cada palabra posible dentro del diccionario.
 *  - Tusalabras: Si las palabras posibles son mas de 10, selecciona las 10
 *    de mayor puntaje.
 * 
 * @author Helmuth Trefftz modificado por Mariana Yepes y Hernan Moreno
 * @version original 2021 04 27
 * @version corregida 2021 04 30
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Diccionario
{
    private ArrayList <String> diccionario = new ArrayList<>();

    /**
     * Constructor
     * Se recibe el nombre del archivo del cual se van a leer las
     * palabras válidas para el juego.
     * 
     * @param nombreArchivo Nombre del archivo a leer.
     */
    public void leerDiccionario(String nombreArchivo) {
        int cont = 0;
        try {
            Scanner in = new Scanner(new File(nombreArchivo));
            while(in.hasNext()) {
                String s = in.next();
                diccionario.add(s);
                cont++;
            }
        } catch(FileNotFoundException e) {
            System.out.println("Ese archivo no se encuentra");
        }
        System.out.println("Lei " + cont + " palabras");
    }

    /**
     * Método ordenarDiccionario
     * Con el fin de poder hacer una búsqueda binaria en el diccionario
     * este se ordena alfabéticament. Para ello se usa el .compareTo
     * que permite determinar si una palabra precede o no alfabeticamente
     * a otra
     * El método no retorna nada pero deja el diccionario ordenado
     * en orden alfabetico en memoria.
     */
    public void ordenarDiccionario(){
        int n = diccionario.size();
        int pos_menor;
        String temp;
        for (int i = 0; i < n-1; i++){
            pos_menor = i;

            for (int j = i+1; j < n; j ++){
                if(diccionario.get(j).compareTo(diccionario.get(pos_menor))<0){
                    pos_menor = j;
                }
            }
            temp = diccionario.get(i);
            diccionario.set(i,diccionario.get(pos_menor));
            diccionario.set(pos_menor,temp);
        }
        for (int i = 0; i<n; i++){
            System.out.println(diccionario.get(i));
        }
    }

    /**
     * Método Tuspalabras
     * Recibe el ArrayList palabrasbuenas que contiene todas las palabras
     * posibles y su puntaje (palabras en posición par, puntaje en posición
     * impar del arreglo), y en caso de haber mas de 10 palabras, selecciona
     * las 10 con puntaje mas alto y las imprime.
     */
    public static void Tuspalabras(){
        int cant = LetterCombinations.palabrasbuenas.size();
        int mayor = 1;
        int i = 1;
        int j = 1;
        System.out.println("Todas las palabras posibles:");
        System.out.println(LetterCombinations.palabrasbuenas);
        System.out.println("Las 10 mejores son:");
        if(cant > 20){

            while(j<=10){

                for(i = 1; i < cant-1; i=i+2){
                    int p1 = Integer.parseInt(LetterCombinations.palabrasbuenas.get(mayor));
                    int p2 = Integer.parseInt(LetterCombinations.palabrasbuenas.get(i+2));
                    if(p1 < p2){
                        mayor = i + 2;
                  
                }
            }
                System.out.print(LetterCombinations.palabrasbuenas.get(mayor-1));
                System.out.print(": puntos: ");
                System.out.println(LetterCombinations.palabrasbuenas.get(mayor));

                LetterCombinations.palabrasbuenas.remove(mayor);
                LetterCombinations.palabrasbuenas.remove(mayor-1);

                j = j + 1;
                cant = cant - 2;
                mayor = 1;
            }
        }
    }


    /**
     * Este método busca una palabra encontrada en el diccionario
     * con el fin de determinar si es válida para el juego.
     * La búsqueda se hace en forma binaria, aprovechando que el 
     * Diccionario ya fue ordenado por el método ordenarDiccionario.
     * Retorna true si la palabra fue encontrada, o false de lo contrario.
     */
    public boolean buscarPalabras(String palabraBuscada) {
        int resul = -1;
        int ini = 0;
        int fin = diccionario.size()-1;
        int pos;
        while(ini<=fin){
            pos = (ini + fin)/2;
            if(palabraBuscada.compareTo(diccionario.get(pos))==0){
                resul = pos;
                return true;
            }else if (palabraBuscada.compareTo(diccionario.get(pos))<0){
                fin = pos - 1;
            }else{
                ini = pos + 1;
            }
        }
        return false;
    }
}
