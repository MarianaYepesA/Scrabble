
/*
1. Tablero - Alberto
2. Faldero - Alfredo
3. Galena - Angela
4. Lacra - Clara
5. Deudora - Eduardo
6. Regador - Gerardo
7. Trecho - Hector
8. Arido - Dario
9. Bailes - Basile
10. Reclamo - Carmelo
11. Trama - Marta
12. Meato - Mateo
13. Camión - Mónica
14. Oscilan - Nicolás
15. Corrida - Ricardo
16. Saunas - Susana 
17. Aretes - Teresa
18. Invocare - Veronica
19. Riesgo - Sergio
20. Ebanistas - Sebastian
 */

/**
 * Esta clase genera posibles palabras a partir de las letras que
 * el usario tiene en su mano
 * @author Helmuth Trefftz
 */
import java.util.ArrayList;
public class LetterCombinations{
    public static ArrayList<String> palabrasbuenas = new ArrayList();
    public static ArrayList<String> newList = new ArrayList<>();
    UsedLetter [] usedLetters;
    int longitud;
    Diccionario diccionario;

    /**
     * En el constructor debe recibir un diccionario con las palabras
     * válidas
     */
    public LetterCombinations(Diccionario diccionario) {
        this.diccionario = diccionario;
    }

    /**
     * Recibir las letras que el usuario tiene en la mano 
     * y guardarlas en el arreglo usedLetters
     * 
     * @param s Letras que el usuario tiene en su mano
     */
    public void init(String s) {
        palabrasbuenas.clear();
        usedLetters = new UsedLetter[s.length()];
        for(int i = 0; i < s.length(); i++) {
            usedLetters[i] = new UsedLetter(s.charAt(i), false);
        }
    }

    /**
     * Método recursivo que genera las posibles variaciones con 
     * las letras que el usuario tiene en la mano.
     * Cada variación se busca en el diccionario para saber si
     * es válida.
     * El método es recursivo.
     * 
     * @param s String que se va conformando hasta el momento.
     */

    public void receiveString(String s) {
        if(s.length() == longitud) {
            if(diccionario.buscarPalabras(s)) {
                if(!palabrasbuenas.contains(s)){
                    palabrasbuenas.add(s);
                    palabrasbuenas.add(String.valueOf(puntaje.puntaje(s)));

                }
            }
        }

        for(int i = 0; i < usedLetters.length; i++) {
            if(!usedLetters[i].used) {
                usedLetters[i].used = true;
                receiveString(s+usedLetters[i].letter);
                usedLetters[i].used = false;
            }
        }
    }

    /**
     * Este método invoca el método receiveString para que  
     * genere palabras de longitud 2, 3, ... n (número de 
     * letras que el usuario tiene en su mano).
     * 
     * @param letrasDeMiMano String con las letras que el usuario tiene
     * en la mano.
     */
    public void crearPalabras(String letrasDeMiMano) {
        String letras = letrasDeMiMano;
        init(letras);
        for(longitud = 2; longitud <= letras.length(); longitud++) {
            receiveString("");
        }
    }

}
