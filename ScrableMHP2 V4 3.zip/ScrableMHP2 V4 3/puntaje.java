/**
 * Clase y método puntaje, el cual recibe como parámetro una palabra
 * encontrada y validada con el diccionario, y calcula su puntaje de 
 * acuerdo a las reglas del juego.
 * @author: Mariana Yepes y Hernan Moreno
 * @version: 2021 04 30
 */

public class puntaje{
public static int puntaje(String palabra) {
    int puntaje = 0;
    String palabraM= palabra.toUpperCase();
    for (int i = 0; i < palabraM.length()-1; i++){
        char letra = palabraM.charAt(i);
        if(palabraM.charAt(i)=='C' &&palabraM.charAt(i+1)=='H'){
              puntaje -=2; 
            }
        else if(palabraM.charAt(i)=='L' &&palabraM.charAt(i+1)=='L'){
              puntaje +=6; 
            }
        else if(palabraM.charAt(i)=='R' &&palabraM.charAt(i+1)=='R'){
              puntaje +=6; 
            }
        }
     for (int i = 0; i < palabraM.length(); i++){
       char letra = palabraM.charAt(i);
        switch (letra) {
            case 'A':
            case 'E':
            case 'I':
            case 'L':
            case 'N':
            case 'O':
            case 'R':
            case 'S':
            case 'T':
            case 'U':
                    puntaje +=1; break;
            case 'G':
            case 'D': puntaje +=2; break;
            
            

 

            case 'B':
            case 'C':
            case 'M':
            case 'P':  puntaje +=3; break;

 

            case 'F':
            case 'H':
            case 'V':
            case 'Y': puntaje +=4; break;

 

            case 'J':
            case 'Ñ':
  
            case 'X':  puntaje +=8; break;

 

            case 'Q':  puntaje +=5; break;
            case 'Z':  puntaje +=10; break;

 

            default: break;
          } 
        } return puntaje;
}
}